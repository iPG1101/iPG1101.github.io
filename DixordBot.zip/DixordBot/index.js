var Discord = require('discord.io');
var w = require('winston');
w.remove(w.transports.Console);
w.add(w.transports.Console, {
    colorize: true
});
w.level = 'debug';
var bot = new Discord.Client({
	'token': 'NDQwMjU5MTk5MjMwOTM1MDUw.DcfJEA.kJu_aSAaECMMQILY-Mathhvu3Qs',
	'autorun': true
});
bot.on('ready', (evt)=>{
	console.log(bot.username + " has been initialized (bot id `" + bot.id + "`)");
});
var waitForRepeat = [];
bot.on('message', (user, userID, channelID, message, evt)=>{
	// bot.sendMessage({
	// 	'to': channelID,
	// 	'message': message
	// });;
	let command = message.split(' ');
	if(message.split('')[0] == '/') {
		if(command[0] == '/help'){
			bot.sendMessage({
				'to': channelID,
				'message': 'Commands you can use: \n - /help: Shows this menu\n - /repeat: Repeats your next message'
			});
		}
		if(command[0] == '/repeat'){
			if(command.length > 1) {
				if(parseInt(command[1]) > 0) {
					for(var i = 0; i < 5 && i < parseInt(command[1]); i++)
					{
						waitForRepeat.push(user);
					}
				}
				else waitForRepeat.push(user);

			}
			else waitForRepeat.push(user);
		}
		if(command[0] == '/js') {
			if(command.length > 1) {
				try{
					delete command[0];
					let math = eval(command.join(' '));
					bot.sendMessage({
						'to': channelID,
						'message': command.join(' ') + " returned: " + math
					});
				} catch(e){console.error(e)}
			}
		}
	} else {
		var r = [];
		for(var i in waitForRepeat) {
			if(waitForRepeat[i] == user) {
				bot.sendMessage({
					'to': channelID,
					'message': message
				});
				r.push(i);
			}
		}
		for(var i in r) {
			delete waitForRepeat[r[i]]
		}
	}
});